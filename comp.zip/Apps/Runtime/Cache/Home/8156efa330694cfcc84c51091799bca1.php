<?php if (!defined('THINK_PATH')) exit();?><html>
字典管理
</html>