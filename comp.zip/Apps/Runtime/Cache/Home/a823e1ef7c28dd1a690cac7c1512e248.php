<?php if (!defined('THINK_PATH')) exit();?><html>
入库管理
</html>