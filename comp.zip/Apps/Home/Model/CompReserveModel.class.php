<?php

namespace Home\Model;
use Think\Model;
class CompReserveModel extends Model {
	protected $tablePrefix = 'tb_'; 
}
